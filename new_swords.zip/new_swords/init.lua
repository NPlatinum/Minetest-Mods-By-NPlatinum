minetest.register_tool("new_swords:admin_sword", {
                   -- (modname:swordname)
    description = "Admin Sword", -- the name that will appear in the creative inventory.
    inventory_image = "admin_sword.png", -- the picture of it, will be found in the "textures" folder.
    tool_capabilities = {
	full_punch_interval = 0.5,
        max_drop_level=1,
        groupcaps={
            snappy={times={[1]=1.00, [2]=0.50, [3]=0.10}, -- how strong it is, the smaller it starts out the stronger.
uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sound = {breaks = "default_tool_breaks"}, -- the sound it will play when broken, will be found in the "sounds" folder, but in this case it will be found in the "default" mod in minetest_game mods.
	groups = {sword = 1}
})

minetest.register_tool("new_swords:platinum_sword", {
    description = "Platinum Sword",
    inventory_image = "platinum_sword.png",
    tool_capabilities = {
	full_punch_interval = 0.8,
        max_drop_level=1,
        groupcaps={
		snappy={times={[1]=1.20, [2]=0.80, [3]=0.20},
uses=45, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("new_swords:obsidian_sword", {
    description = "Obsidian Sword",
    inventory_image = "obsidian_sword.png",
    tool_capabilities = {
	full_punch_interval = 0.9,
        max_drop_level=1,
        groupcaps={
            snappy={times={[1]=1.50, [2]=0.65, [3]=0.25},
uses=40, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("new_swords:ruby_sword", {
    description = "Ruby Sword",
    inventory_image = "ruby_sword.png",
    tool_capabilities = {
	full_punch_interval = 0.5,
        max_drop_level=0,
        groupcaps={
            snappy={times={[1]=1.00, [2]=0.50, [3]=0.10},
uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("new_swords:glass_sword", {
	description = "Glass Sword",
	inventory_image = "glass_sword.png",
	tool_capabilities = {
		full_punch_interval = 1,
		max_drop_level=0,
		groupcaps={
			snappy={times={[2]=1.6, [3]=0.40}, uses=10, maxlevel=1},
		},
		damage_groups = {fleshy=2},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("new_swords:amber_sword", {
    description = "Amber Sword",
    inventory_image = "amber_sword.png",
    tool_capabilities = {
	full_punch_interval = 0.5,
        max_drop_level=0,
        groupcaps={
            snappy={times={[1]=1.00, [2]=0.50, [3]=0.10},
uses=50, maxlevel=3},
		},
		damage_groups = {fleshy=9},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

minetest.register_tool("new_pickaxes:pick_admin", {
	description = "Admin Pickaxe",
	inventory_image = "admin_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=3.0, [2]=2.0, [3]=1.0}, uses=40, maxlevel=6},
		},
		damage_groups = {fleshy=3},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})
